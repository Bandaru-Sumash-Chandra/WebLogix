from pydantic import BaseModel, Field

class InventoryItem(BaseModel):
    id: int = Field(default=None)
    name: str = Field(...)
    category: str = Field(...)
    description: str = Field(...)
    price: float = Field(...)
    quantity: int = Field(...)
