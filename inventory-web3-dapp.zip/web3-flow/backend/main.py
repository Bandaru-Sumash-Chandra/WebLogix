
import uvicorn
from fastapi import FastAPI ,Body, Depends, Request, Response, HTTPException 
from app.model import PostSchema, UserSchema, UserLoginSchema, GenerateSchema
from app.auth.auth_bearer import JWTBearer
from app.auth.auth_handler import get_password_hash , signJWT , verify_password
from app.helpers.helpers import *
import httpx
from starlette.responses import RedirectResponse
from fastapi.middleware.cors import CORSMiddleware 
import mysql.connector
import pymysql
import requests
from github import Github
from pydantic import BaseSettings
import openai
import os
from pydantic import BaseModel

app = FastAPI()

origins = [
    "http://localhost",
    "http://localhost:3000",
    '*'
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

openai.api_key = "YOUR_OPENAI_API_KEY"

users = []

''' ====================== MYSQL Cloud Connection ======================'''

conn = pymysql.connect(
    host = os.environ['MYSQL_HOST'],
    user=os.environ['MYSQL_USER'],
    password=os.environ['MYSQL_PASSWORD'],
    port = 25060,
    database=os.environ['MYSQL_DB']
)

github_client_id = os.environ['GH_CLIENT_ID']
github_client_secret = os.environ['GH_SECRET_ID']
openai.api_key = os.environ['OPENAI_API_KEY']


class PromptInput(BaseModel):
    prompt: str

def main():
    try:
        cursor = conn.cursor()
        # cursor.execute("DROP TABLE users")
        cursor.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTO_INCREMENT, username TEXT , password TEXT)")  #MYSQL
        conn.commit()

        print("Connection to MySQL DB successful")
    except mysql.connector.Error as error: 
        print(f"Failed to connect to MySQL: {error}")

def get_db():
    try:
        return conn
    except mysql.connector.Error as error:
        raise HTTPException(status_code=500, detail="Unable to connect to the database")

@app.post("/generate-response")
async def generate_response(prompt_input: PromptInput):
    query = text("SELECT response FROM responses WHERE prompt LIKE :prompt")
    with cursor.connect() as conn:
        result = conn.execute(query, {"prompt": f"%{prompt_input.prompt}%"})
        rows = result.fetchall()
        if not rows:
            raise HTTPException(status_code=404, detail="No response found for the prompt")

        responses = [row["response"] for row in rows]
        input_text = " ".join(responses)
 
    generated_response = f"This is a generated response using OpenAI based on the input: {input_text}"
    
    return {"generated_response": generated_response}

@app.post("/generate_inventory_details")
async def generate_inventory_details(prompt: str = Body(...)):
  """
  Generates inventory details based on a user prompt using OpenAI.
  """
  
  full_prompt = f"Generate inventory items to be added: {prompt}"

  response = openai.Completion.create(
      engine="text-davinci-003",
      prompt=full_prompt,
      max_tokens=150, 
      n=1,
      stop=None,
      temperature=0.7, 
  )
  
  completion = response.choices[0].text.strip()
  return {"inventory_details": completion}


if __name__ == "__main__":
    main()
    uvicorn.run(app, host='0.0.0.0', port=8001)