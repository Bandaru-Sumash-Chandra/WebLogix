import React, { useEffect, useState } from 'react';
import { ArrowDownOutlined, ArrowUpOutlined } from '@ant-design/icons';
import { Card, Col, Flex, Progress, Row, Statistic, Tooltip, Typography } from 'antd';
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const {Text} = Typography;

 
  
const Dashboard = () => {
    const [stepsCount, setStepsCount] = React.useState(5);
  const [stepsGap, setStepsGap] = React.useState(3);
  const [statsData, setStatsData] = useState([]);

  const conicColors = {
    '0%': '#87d068',
    '20%': '#ffe58f',
    '50%': '#ffccc7',
  };

  const { data } = useQuery({
    queryKey: "super-heroes",
    queryFn: async () => {
      await axios.get("http://localhost:4000/stats").
      then(res => res.data)
    },
  });

  useEffect(()=>{
    setStatsData(data.stats)
  },[data])

  return (
    <>
     <Row gutter={16}>
    <Col span={6}>
      <Card bordered={false}>
        <Statistic
          title="Total Products"
          value={statsData.total_products} 
          valueStyle={{
            color: '#3f8600',
          }}
          prefix={<ArrowUpOutlined />}
          // suffix="%"
        />
      </Card>
    </Col>
    <Col span={6}>
      <Card bordered={false}>
        <Statistic
          title="Profit Margins"
          value={statsData.proft_margin}
          precision={2}
          valueStyle={{
            color: '#cf1322',
          }}
          prefix={<ArrowDownOutlined />}
          suffix="%"
        />
      </Card>
    </Col>
   
    <Col span={6}>
      <Card bordered={false}>
        <Statistic
          title="Total Revenue"
          value={statsData.total_revenue} 
          valueStyle={{
            color: '#3f8600',
          }}
          prefix={"$"} 
        />
      </Card>
    </Col>

    <Col span={6}>
      <Card bordered={false}>
        <Statistic
          title="Total Category"
          value={statsData.total_cat} 
          valueStyle={{
            color: '#3f8600',
          }}  
        />
      </Card>
    </Col>
 

    <Col className='my-5' span={6}>
    <div class="mx-auto flex max-w-xs flex-col gap-y-4">
        <dt class="text-base leading-7 text-gray-600">Total emissions (tCO2e)</dt>
        <dd class="order-first text-3xl font-semibold tracking-tight text-gray-900 sm:text-5xl">{statsData.emission}</dd>
      </div>
    </Col>

    <Col className='my-5' span={18}>
    <Flex gap="small" vertical>
      <Text>Total Composition of Carbon footprint</Text>
    <Tooltip title={statsData.carbon_footprint}>
      <Progress 
      strokeColor={conicColors}
       percent={100} />
    </Tooltip> 
  </Flex>
    </Col>

   


  </Row> 

  <Row gutter={25}>
    <Col span={11}>

  <p className="mt-6 text-xl font-bold leading-7 text-gray-600">My Inventory</p>
          
    <ul role="list" className="divide-y divide-gray-100">
      {statsData.people.map((person) => (
        <li key={person.email} className="flex justify-between gap-x-6 py-5">
          <div className="flex min-w-0 gap-x-4">
            <div className="min-w-0 flex-auto">
              <p className="text-sm font-semibold leading-6 text-gray-500">{person.name}</p>
            </div>
          </div>
          <div className="hidden shrink-0 sm:flex sm:flex-col sm:items-end">
            <p className="text-sm leading-6 text-gray-900">{person.role}</p>
  
          </div>
        </li>
      ))}
    </ul>
    </Col> 
    <Col span={12} className='ml-16'>

<p className="mt-6 text-xl font-bold leading-7 text-gray-600">Your Team</p>
        
  <ul role="list" className="divide-y divide-gray-100">
    {statsData.team.map((person) => (
      <li key={person.email} className="flex justify-between gap-x-6 py-5">
        <div className="flex min-w-0 gap-x-4">
          <img className="h-12 w-12 flex-none rounded-full bg-gray-50" src={person.imageUrl} alt="" />
          <div className="min-w-0 flex-auto">
            <p className="text-sm font-semibold leading-6 text-gray-900">{person.name}</p>
            <p className="mt-1 truncate text-xs leading-5 text-gray-500">{person.email}</p>
          </div>
        </div>
        <div className="hidden shrink-0 sm:flex sm:flex-col sm:items-end">
          <p className="text-sm leading-6 text-gray-900">{person.role}</p>
          {person.lastSeen ? (
            <p className="mt-1 text-xs leading-5 text-gray-500">
              Last seen <time dateTime={person.lastSeenDateTime}>{person.lastSeen}</time>
            </p>
          ) : (
            <div className="mt-1 flex items-center gap-x-1.5">
              <div className="flex-none rounded-full bg-emerald-500/20 p-1">
                <div className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              </div>
              <p className="text-xs leading-5 text-gray-500">Online</p>
            </div>
          )}
        </div>
      </li>
    ))}
  </ul>
  </Col>

  </Row> 
      </>
 );
};
export default Dashboard;