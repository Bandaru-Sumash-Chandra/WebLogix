export const Categories = [
    {
      label : "Electronics",
      value: "Electronics"
    },
    {
      label : "Clothing",
      value: "Clothing"
    },
    {
      label : "Toys",
      value: "Toys"
    }
  ]