import { EditOutlined, EllipsisOutlined, LoadingOutlined, SendOutlined, SettingOutlined, UploadOutlined } from "@ant-design/icons";
import { Typography, Button, Card, Col, Drawer, Form, Input, message, Row, Select, Skeleton, Space, Spin, Tag, Upload, notification, Popover, QRCode } from "antd";
import { useEffect, useState } from "react";
import { Categories } from "./Inventory.utils";
import * as fcl from "@onflow/fcl"
import { useQuery, useMutation , useQueryClient} from "@tanstack/react-query";
import axios from "axios";

const { Option } = Select;

const products = [
  { 
    id: 1,
    name: 'Basic Tee', 
    imageSrc: 'https://tailwindui.com/img/ecommerce-images/product-page-01-related-product-01.jpg', 
    category: 'Clothing',
    price: '$35', 
  }, 
  { 
    id: 2,
    name: 'Premium Hoodie', 
    imageSrc: 'https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?q=80&w=1972&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Clothing',
    price: '$60', 
  }, 
  { 
    id: 3,
    name: 'Running Shoes', 
    imageSrc: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2hvZXN8ZW58MHx8MHx8fDA%3D', 
    category: 'Shoes',
    price: '$80', 
  }, 
  { 
    id: 4,
    name: 'Wireless Headphones', 
    imageSrc: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&w=2065&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Electronics',
    price: '$120', 
  }, 
  { 
    id: 5,
  name: 'Toy Train',
  imageSrc: 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
  category: 'Toys',
  price: '$80', 
  }, 
  { 
    id: 6,
    name: 'Smartwatch', 
    imageSrc: 'https://images.unsplash.com/photo-1544117519-31a4b719223d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8c21hcnQlMjB3YXRjaHxlbnwwfHwwfHx8MA%3D%3D', 
    category: 'Electronics',
    price: '$150', 
  }, 
  { 
    id: 7,
    name: 'Smartphone', 
    imageSrc: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?q=80&w=2118&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Electronics',
    price: '$800', 
  }, 
  { 
    id: 8,
    name: 'Laptop', 
    imageSrc: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Electronics',
    price: '$1200', 
  }, 
  { 
    id: 9,
    name: 'Wireless Mouse', 
    imageSrc: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?q=80&w=2067&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Electronics',
    price: '$40', 
  }, 
  { 
    id: 10,
    name: 'Bluetooth Speaker', 
    imageSrc: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=1931&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Electronics',
    price: '$100', 
  }, 
  { 
    id: 12,
    name: 'Teddy bear', 
    imageSrc: 'https://images.unsplash.com/photo-1556012018-50c5c0da73bf?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D', 
    category: 'Toys',
    price: '$20', 
  }, 

  { 
    id: 13,
    name: 'Basic Shirt', 
    imageSrc: 'https://tailwindui.com/img/ecommerce-images/product-page-01-related-product-03.jpg',
    category: 'Clothing',
    price: '$30', 
  },
];


const { Meta } = Card;
const { Text, Link } = Typography;


export default function Inventory() {
  const [products, setProducts] = useState([]);
  const [api, contextHolder] = notification.useNotification();
  const openNotificationWithIcon = (type) => {
    api[type]({
      message: 'Inventory Added',
      description:
        'Inventory saved in web3 block successfully! Block ID: b4725454556de01cebb98163d86ab2252255b5be69b2177c99dc7bc9d9c5b66a',
    });
  };
 

  const handleAIData = () => {
    const queryClient = useQueryClient();
    return useMutation({
      mutationKey: ["add-ai-data"],
      mutationFn: useAddAiData,
      onSuccess: (data) => { 
        queryClient.setQueryData("products", (oldQueryData) => {
          return {
            ...oldQueryData,
            data: [...oldQueryData.data, data.data],
          };
        });
      },
    });
  };

  const { data } = useQuery({
    queryKey: "products",
    queryFn: async () => {
      await axios.get("http://localhost:4000/products").
      then(res => res.data)
    },
  });

 
  useEffect(()=>{
    setProducts(data.products)
  },[data])

  const props = {
    name: 'file',
    action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',
    headers: {
      authorization: 'authorization-text',
    },
    onChange(info) {
      if (info.file.status !== 'uploading') {
        console.log(info.file, info.fileList);
      }
      if (info.file.status === 'done') {
        message.success(`${info.file.name} file uploaded successfully`);
      } else if (info.file.status === 'error') {
        message.error(`${info.file.name} file upload failed.`);
      }
    },
  };

  const [open, setOpen] = useState(false);
  const [show, setShow] = useState(false);
  const showDrawer = () => {
    setOpen(true);
  };
  const onClose = () => {
    setOpen(false);
  };

  const [loading, setLoading] = useState(false);
  const showSkeleton = (val) => {
    setLoading(true);
    setShow(true);
    handleAIData(val);
    setTimeout(() => {
      openNotificationWithIcon('success');
      setLoading(false); 
      // window.location.reload();
    }, 4000);
  };


  const createTransaction = async  (values) => {
    console.log('Success:', values); 
    

    const transactionId = await fcl.mutate({
      cadence : `
      transaction {
  prepare(acct: AuthAccount) {
    log("Hello from prepare")
     
    let inventoryData  = values
 
    let addedItems  = []
    for item in inventoryData {
      addedItems.append(item)
    }
    
    log("Inventory data to be added:", addedItems)
  }
  execute(inventoryData) {
    log("Hello from execute")
     
    let itemsToAdd = inventoryData 

    log("Successfully added", itemsToAdd.length, "items to inventory.")
  }
}

      `,
  

      
      proposer: fcl.currentUser,
      payer: fcl.currentUser,
      authorizations: [fcl.currentUser],
      limit: 50
    })


    openNotificationWithIcon('success');

    const transaction = await fcl.tx(transactionId).onceSealed()
    console.log(transaction) 
    
    // const [result, error, logs] = await shallPass(
    //   sendTransaction("log-message", [], args)
    // )
    // console.log({result}, {error}, {logs})
  
  }


    return (
      <>

<div style={{ padding: 24, textAlign: "center" }}>
  <h1 class="text-3xl font-bold tracking-tight text-gray-900">Know about your inventory with Open AI</h1>
    <div className="mt-2 inline-flex space-x-4">
    <Tag className="cursor-pointer">Say total count of my inventory</Tag>
    <Tag className="cursor-pointer">Add remote control toy to my inventory</Tag>
    <Tag className="cursor-pointer">Show all inventory of Electronics</Tag>
    <Tag className="cursor-pointer"
    onClick={showSkeleton} 
    >Say total count of inventory in electronics</Tag>
    </div>
  <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 flex items-center">
    <i class="fas fa-question-circle mr-2 text-gray-500"></i>  <input type="text" class="rounded-md border border-gray-300 px-4 py-2 w-full focus:outline-none focus:ring-1 focus:ring-blue-500" placeholder="eg: Count all materials in my inventory" />
    <button type="submit"
    onClick={showSkeleton} 
    disabled={loading} 
    class="ml-2 bg-[#001529] text-white font-bold py-2 px-4 rounded-md">
    <SendOutlined />
    </button>
  </div>

{loading ?
  <Spin
    indicator={
      <LoadingOutlined
        style={{
          fontSize: 24,
        }}
        spin
      />
    }
  />
  :
show && (
  <Text
  className="font-bold text-lg text-slate-600"
  keyboard>{data.value}</Text>  
)
}
 
       
       

</div>

      {/* <div
        style={{
          padding: 24,
          textAlign: "center", 
        }}
        >

      <h1 className="text-3xl font-bold tracking-tight text-gray-900">Ask Anything to AI</h1>
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      </div>
    </div>  */}

    <div className="bg-white">

    <div className="flex px-6 justify-between">
        <h2 className="text-2xl font-bold tracking-tight text-gray-700">My Inventory</h2>
        <div className="space-x-5">
        <Button onClick={showDrawer}  >Add Inventory</Button>
        <Select placeholder="Filter by inventory"
        options={Categories}
        />
                 
        </div>
        
        </div>

      <div className="px-4 max-w-8xl"> 
        <div className="mt-6 grid  gap-y-10 grid-cols-5 xl:gap-x-8">
          {products.map((product) => (
            
            <div key={product.id} className="group relative">
              <Card
    style={{ width: 300 }}
    cover={
      <img 
        src={product.imageSrc}
        alt="inventory" 
        className="h-60 w-full object-cover"
        />
    }
    actions={[ 
      <EditOutlined key="edit" />,
      <Popover
      overlayInnerStyle={{
        padding: 0,
      }}
      content={
      <div>
      <QRCode  
        value="https://flow-view-source.com/testnet/tx/b4725454556de01cebb98163d86ab2252255b5be69b2177c99dc7bc9d9c5b66a" bordered={false} />
        <p className="ml-2 text-gray-400 text-sm">Verify your transaction</p>
        </div>}
    >
      <EllipsisOutlined key="ellipsis" />
    </Popover>

    ]}
  >
     <div className="mt-4 flex justify-between">
                <div>
                  <h3 className="text-sm text-gray-700">
                    <a href={product.href}>
                      <span aria-hidden="true" className="absolute inset-0" />
                      {product.name}
                    </a>
                  </h3>
                  <p className="mt-1 text-sm text-gray-500">{product.category} | #INVID{product.id}</p>                  
                </div>
                <p className="text-sm font-medium text-gray-900">{product.price}</p>
              </div> 
  </Card>
             
            </div>
          ))}
        </div>
      </div>
    </div>

    {contextHolder}
    <Drawer
        title="Add an inventory"
        width={720}
        onClose={onClose}
        open={open}
        styles={{
          body: {
            paddingBottom: 80,
          },
        }}
        extra={
          <Space>
            <Button onClick={onClose}>Cancel</Button>
            <Button  
            onClick={createTransaction}
            className="bg-[#001529] text-white">
            Add Inventory
            </Button>
          </Space>
        }
      >
        <Form layout="vertical"  onFinish={createTransaction}>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                name="name"
                label="Name"
                rules={[
                  {
                    required: true,
                    message: 'Please enter product name',
                  },
                ]}
              >
                <Input placeholder="Please enter product name" />
              </Form.Item>
            </Col>
            <Col span={12}>
            <Form.Item
                name="id"
                label="Inventory ID"
                rules={[
                  {
                    required: true,
                    message: 'Please enter inventory id',
                  },
                ]}
              > 
                <Input placeholder="Please enter inventory id" />
              </Form.Item> 
            </Col>
            <Col span={12}>
            <Form.Item
                name="category"
                label="Category"
                rules={[
                  {
                    required: true,
                    message: 'Please select category',
                  },
                ]}
              >
                <Select placeholder="Please select a category"
                options={Categories}
                /> 
              </Form.Item> 
            </Col>
            <Col  span={12}>

            <Form.Item
                name="image"
                label="Image"
                rules={[
                  {
                    required: true,
                    message: 'Select an image',
                  },
                ]}
              >
            
               <Upload 
               {...props}>
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
              </Form.Item> 

            
            </Col>

            <Col span={12}>
            <Form.Item
                name="Price"
                label="Price"
                rules={[
                  {
                    required: true,
                    message: 'Enter price',
                  },
                ]}
              >
            <Input placeholder="Please enter price" />
              </Form.Item> 
            </Col>

            <Col span={12}>
              <Form.Item
                name="desc"
                label="Description"
                rules={[
                  {
                    required: true,
                    message: 'Please enter price',
                  },
                ]}
              >
                <Input placeholder="Please enter user name" />
              </Form.Item>
            </Col>
           

          </Row>
         
        </Form>
      </Drawer>
      </>
    ); 
}