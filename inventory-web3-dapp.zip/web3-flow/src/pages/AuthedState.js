import React from "react";
import { Layout, Menu, theme } from "antd";
import {
  AppstoreOutlined,
  TeamOutlined,
  ShopOutlined, 
  UserOutlined,
} from "@ant-design/icons";
import Dashboard from "./Dashboard";
import {
  BrowserRouter,
  Routes,
  Route, 
} from "react-router-dom";
import Inventory from "./Inventory";
import User from "./User";

const { Header, Content, Footer, Sider } = Layout;

const AuthedState = ({
  sendQuery,
  initAccount,
  unauthenticate,
  address,
  name,
}) => {
  const items = [
    { icon: AppstoreOutlined, label: "Dashboard", url: "/" },
    { icon: ShopOutlined, label: "Inventory", url: "/inventory" },
    { icon: TeamOutlined , label: "Collaborator", url: "/collaborators" },
    { icon: UserOutlined, label: "User Profile", url: "/user" },
  ].map((item, index) => ({
    key: String(index + 1),
    icon: React.createElement(item.icon),
    label: (
      <a href={`${item.url}`} rel="noopener noreferrer">
        {item.label}
      </a>
    ),
  }));

  const menuItems = [
    { func: sendQuery, label: "Send Query" },
    { func: initAccount, label: "Init Account" },
    { func: unauthenticate, label: "Log Out" },
  ].map((item, index) => ({
    key: String(index + 1),
    label: (
      <a
        className="font-bold text-gray-600"
        onClick={item.func}
        rel="noopener noreferrer"
      >
        {item.label}
      </a>
    ),
  }));

  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  return (
    <Layout hasSider>
      <Sider
        style={{
          overflow: "auto",
          height: "100vh",
          position: "fixed",
          left: 0,
          top: 0,
          bottom: 0,
        }}
      >
        <div className="demo-logo-vertical" />
        <Menu
          theme="dark"
          mode="inline" 
          items={items}
        />
      </Sider>
      <Layout
        style={{
          marginLeft: 200,
        }}
      >
        <Header
          style={{
            padding: "0 10px",
            background: colorBgContainer,
            position: "sticky",
            taop: 0,
            zIndex: 1,
            width: "100%",
            display: "flex",
            alignItems: "center",
          }}
        >
          <div className="inline-flex w-full justify-end">
            <Menu
              mode="horizontal"
              items={menuItems}
              style={{
                flex: 2,
                minWidth: 0,
              }}
            />

            <div className="font-medium text-gray-600">
              {address}/{name}
            </div>
          </div>
        </Header>
        <Content
          style={{
            margin: "24px 16px 0",
            overflow: "initial",
          }}
        >
          <div
            style={{
              padding: 24,
              // textAlign: "center",
              background: colorBgContainer,
              borderRadius: borderRadiusLG,
            }}
          >
            <BrowserRouter>

            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/user" element={<User />} />
            </Routes>
            </BrowserRouter>
          </div>
        </Content>
        {/* <Footer
          style={{
            textAlign: "center",
          }}
        >
          Ant Design ©{new Date().getFullYear()} Created by Ant UED
        </Footer> */}
      </Layout>
    </Layout>
  );
};
export default AuthedState;
