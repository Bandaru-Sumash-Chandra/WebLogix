export default function UnauthenticatedState({ onLogin, onSignUp }) {
  return (
    <>
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">
          {/* <img
            className="mx-auto h-10 w-auto"
            src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=600"
            alt="Your Company"
          /> */}
          <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
            Login to inventory dashboard
          </h2> 
            <img
              className="w-[40rem] mt-5 rounded-md bg-white/5 ring-1 ring-white/10"
              src="https://cdn.dribbble.com/users/2883527/screenshots/16175653/media/cb66719cadb61dca4b678a2be9559e9b.png"
              alt="App screenshot" 
            /> 
        </div>

       
          <br />

        <div className="mt-10 space-y-5 sm:mx-auto sm:w-full sm:max-w-sm"> 
                    <div>
                <button
                  type="submit"
                  onClick={onLogin}
                  className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                >
                  Log in
                </button>
              </div>

              <div>
                <button
                  type="submit"
                  onClick={onSignUp}
                 className="flex w-full justify-center rounded-md bg-white px-3 py-1.5 text-sm font-semibold leading-6 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300"
                >
                  Sign Up
                </button>
              </div>   
        </div>
      </div>
    </>
  );
}
