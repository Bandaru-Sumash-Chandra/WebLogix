import { config } from "@onflow/fcl";

config({
  "accessNode.api": "https://rest-testnet.onflow.org", 
  "discovery.wallet": "https://fcl-discovery.onflow.org/testnet/authn" , 
  "discovery.authn.endpoint": "https://fcl-discovery.onflow.org/api/testnet/authn",
  "0xProfile":"0x281f42961b7fa3a5"
})
