import "./App.css";
import "./flow/config";
import { useState, useEffect } from "react";
import * as fcl from "@onflow/fcl";
import AuthedState from "./pages/AuthedState";
import UnauthenticatedState from "./pages/UnauthenticatedState";

export default function App() {
  const [user, setUser] = useState({ loggedIn: null });
  const [name, setName] = useState("No Profile");
  const [transactionStatus, setTransactionStatus] = useState(null);

  useEffect(
    () =>
      fcl.currentUser.subscribe((userData) => {
        setUser(userData);
        console.log(userData);
      }),
    []
  );
  // uses FCL to subscribe the user that logs in or signs up

  const sendQuery = async () => {
    const profile = await fcl.query({
      cadence: `
        import Profile from 0xProfile

        pub fun main(address: Address): Profile.ReadOnly? {
          return Profile.read(address)
        }
      `,
      args: (arg, t) => [arg(user.addr, t.Address)],
    });

    setName(profile?.name ?? "No Profile");
  };

  const executeTransaction = async () => {
    const transactionId = await fcl.mutate({
      cadence: `
        import Profile from 0xProfile

        transaction(name: String) {
          prepare(account: AuthAccount) {
            account
              .borrow<&Profile.Base{Profile.Owner}>(from: Profile.privatePath)!
              .setName(name)
          }
        }
      `,
      args: (arg, t) => [arg("MLH", t.String)],
      payer: fcl.authz,
      proposer: fcl.authz,
      authorizations: [fcl.authz],
      limit: 50,
    });

    fcl.tx(transactionId).subscribe((res) => setTransactionStatus(res.status));
  };

  const AuthedStatessss = () => {
    // function updates the user variable as true or false based on whether a user is logged in or not.

    return (
      // <AuthedState />
      // generates a log out button if loggedIn is true
      <div className="bg-gray-900">
        <div>Address: {user?.addr ?? "No Address"}</div>
        <div>Profile Name: {name ?? "--"}</div> {/* NEW */}
        <button onClick={sendQuery}>Send Query</button> {/* NEW */}
        <button onClick={initAccount}>Init Account</button> {/* NEW */}
        <button onClick={fcl.unauthenticate}>Log Out</button>
      </div>
    );
  };

  const initAccount = async () => {
    const transactionId = await fcl.mutate({
      cadence: `
            import Profile from 0xProfile
      
            transaction {
              prepare(account: AuthAccount) {
                // Only initialize the account if it hasn't already been initialized
                if (!Profile.check(account.address)) {
                  // This creates and stores the profile in the user's account
                  account.save(<- Profile.new(), to: Profile.privatePath)
      
                  // This creates the public capability that lets applications read the profile's info
                  account.link<&Profile.Base{Profile.Public}>(Profile.publicPath, target: Profile.privatePath)
                }
              }
            }d
          `,
      payer: fcl.authz,
      proposer: fcl.authz,
      authorizations: [fcl.authz],
      limit: 50,
    });

    const transaction = await fcl.tx(transactionId).onceSealed();
    console.log(transaction);
  };

  return (
    <div>
      {user.loggedIn ? (
        <AuthedState
          sendQuery={sendQuery}
          initAccount={initAccount}
          unauthenticate={fcl.unauthenticate}
          address={user?.addr ?? "No Address"}
          name={name ?? "Default Name"}
        />
      ) : (
        <UnauthenticatedState onLogin={fcl.logIn} onSignUp={fcl.signUp} />
      )}
    </div>
  );
}
